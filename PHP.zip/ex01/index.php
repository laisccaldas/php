<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Me livrando da Maldição</title>
</head>
<body>
    <h1>
        <?php
echo "Olá, Mundo!\u{1F30E}";
        ?>
    </h1>
    <p>Vamos tentar nos livrar da maldição</p>
</body>
</html>